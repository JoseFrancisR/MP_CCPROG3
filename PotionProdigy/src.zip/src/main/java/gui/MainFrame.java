/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package gui;

import controller.Controller;
import java.awt.CardLayout;
import gui.components.Theme;

/**
 * main application window. The frame owns the controller
 * and uses a CardLayout to display the different game screens.
 */
public class MainFrame extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(MainFrame.class.getName());

    private final Controller CONTROLLER;
    private final CardLayout CARD_LAYOUT;
    
    private StartPanel startPanel;
    private MainMenuPanel mainMenuPanel;
    private BrewPanel brewPanel;
    private InventoryPanel inventoryPanel;
    private SpellbookPanel spellbookPanel;
    private MarketPanel marketPanel;
    
    private RecipePanel recipePanel;
    private CreativePanel creativePanel;
    
    /**
     * creates the application window, controller, and all navigatable screen panels
     */
    public MainFrame() {
        initComponents();
        
        getContentPane().removeAll();
        getContentPane().setLayout(new java.awt.BorderLayout());
        getContentPane().add(contentPanel, java.awt.BorderLayout.CENTER);
        
        setMinimumSize(new java.awt.Dimension(720, 600));
        setSize(new java.awt.Dimension(720, 600));
        
        this.CONTROLLER = new Controller();
        this.CARD_LAYOUT = (CardLayout)contentPanel.getLayout();

        this.startPanel = new StartPanel(this, CONTROLLER);
        this.mainMenuPanel = new MainMenuPanel(this, CONTROLLER);
        this.brewPanel = new BrewPanel(this, CONTROLLER);
        this.inventoryPanel = new InventoryPanel(this, CONTROLLER);
        this.spellbookPanel = new SpellbookPanel(this, CONTROLLER);
        this.marketPanel = new MarketPanel(this, CONTROLLER);
        this.creativePanel = new CreativePanel(this, CONTROLLER);
        this.recipePanel = new RecipePanel(this, CONTROLLER);

        contentPanel.add(startPanel, "START");
        contentPanel.add(mainMenuPanel, "MENU");
        contentPanel.add(brewPanel, "BREW");
        contentPanel.add(inventoryPanel, "INVENTORY");
        contentPanel.add(spellbookPanel, "SPELLBOOK");
        contentPanel.add(marketPanel, "MARKET");
        contentPanel.add(recipePanel, "RECIPE");
        contentPanel.add(creativePanel, "CREATIVE");
        
        Theme.apply(this);
        
        showStart();
        
        setTitle("Potion Prodigy");

        contentPanel.revalidate();
        contentPanel.repaint();
        
        setLocationRelativeTo(null);
    }
    /**
     * Returns the controller shared by all screens.
     *
     * @return application controller
     */
    public Controller getController() {
        return this.CONTROLLER;
    }
    /**
     * Returns the panel containing all screens managed by the card layout.
     *
     * @return main content panel
     */
    public javax.swing.JPanel getContentPanel() {
        return this.contentPanel;
    }
    /**
     * Returns the layout used to switch between screens.
     *
     * @return card layout of the main content panel
     */
    public CardLayout getCardLayout() {
        return this.CARD_LAYOUT;
    }
    /** Displays the new-game and load-game screen. */
    public void showStart() {
        CARD_LAYOUT.show(contentPanel, "START");
    }
    /** Refreshes and displays the main-menu screen. */
    public void showMainMenu() {
        mainMenuPanel.refreshDisplay();
        CARD_LAYOUT.show(contentPanel, "MENU");
    }
    /** Displays the brewing-mode selection screen. */
    public void showBrew() {
        CARD_LAYOUT.show(contentPanel, "BREW");
    }
    /** Refreshes and displays the inventory screen. */
    public void showInventory() {
        inventoryPanel.refreshDisplay();
        CARD_LAYOUT.show(contentPanel, "INVENTORY");
    }
    /** Refreshes and displays the player's spellbook. */
    public void showSpellbook() {
        spellbookPanel.refreshDisplay();
        CARD_LAYOUT.show(contentPanel, "SPELLBOOK");
    }
    /** Refreshes and displays the market screen. */
    public void showMarket() {
        marketPanel.refreshDisplay();
        CARD_LAYOUT.show(contentPanel, "MARKET");
    }
    /** Refreshes and displays the creative brewing screen. */
    public void showCreative() {
        creativePanel.refreshDisplay();
        CARD_LAYOUT.show(contentPanel, "CREATIVE");
    }
    /** Refreshes and displays the recipe brewing screen. */
    public void showRecipe() {
        recipePanel.refreshDisplay();
        CARD_LAYOUT.show(contentPanel, "RECIPE");
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        contentPanel = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Potion Prodigy");
        setMinimumSize(new java.awt.Dimension(720, 600));
        setPreferredSize(new java.awt.Dimension(720, 600));

        contentPanel.setLayout(new java.awt.CardLayout());

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(contentPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(603, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(contentPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(484, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel contentPanel;
    // End of variables declaration//GEN-END:variables
}
