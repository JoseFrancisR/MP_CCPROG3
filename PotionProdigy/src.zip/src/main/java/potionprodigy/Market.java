package potionprodigy;

import java.util.ArrayList;
import java.util.Random;

/**
 * Manages market generation, buying, and selling.
 */
public class Market {

    /** Up to eight listings shown during the current market visit. */
    private ArrayList<Listing> listings;

    /** True after the market has been generated during the current session. */
    private boolean generatedThisSession;

    /** Creates an empty market. */
    public Market() {
        listings = new ArrayList<>();
        generatedThisSession = false;
    }

    /**
     * Generates eight random market slots.
     *
     * @param ingredients complete list of fruits and bases
     */
    public void generateListings(ArrayList<Ingredient> ingredients) {
        listings.clear();
        Random rand = new Random();
        int i, qty, price;
        boolean cauldronExists = false;

        if (ingredients != null && !ingredients.isEmpty()) {
            for (i = 0; i < 8; i++) {
                if (rand.nextInt(8) == 0 && !cauldronExists) { // Randomly generates a cauldron
                    Listing listing = new Listing(i + 1, null, 1, 3000, true);
                    cauldronExists = true;
                    listings.add(listing);
                } else {
                    Ingredient ingredient = ingredients.get(rand.nextInt(ingredients.size()));
                    qty = rand.nextInt(5) + 1;
                    price = ingredient.getBuyingPrice();
                    Listing listing = new Listing(i + 1, ingredient, qty, price, false);
                    listings.add(listing);
                }
            }
            generatedThisSession = true;
        } else {
            generatedThisSession = false;
        }
    }

    /** Replaces the existing listings when a refresh condition is met. */
    public void refresh() {
        listings.clear();
        generateListings(Ingredient.loadIngredients());
    }

    /**
     * Buys several selected market slots in one procedure.
     *
     * @param player      purchasing player
     * @param slotNumbers selected slot numbers
     */
    public ArrayList<Integer> buyMultiple(Player player, ArrayList<Integer> slotNumbers) {
        ArrayList<Integer> results = new ArrayList<>();
        int status, i;
        boolean found;
        Listing targetListing;
        for (Integer slot : slotNumbers) {
            found = false;
            targetListing = null;
            // search through the listing and check the slot number
            for(i =0; i < listings.size() && !found; i++){
                Listing listing = listings.get(i);
                if(listing.getSlotNumber() == slot){
                    targetListing = listing;
                    found = true;
                }
            }
            if(targetListing != null){ 
                status = targetListing.purchase(player);
                results.add(status); // individually shows the player whether the purchase for a specific listing is succesful
            } else{ //invalid slot number
                results.add(-2);
            } 
        }
        return results;
    }

    /**
     * Sells several selected ingredient stacks in one procedure.
     *
     * @param player selling player
     * @param items  selected ingredients and quantities
     */
    public void sellMultiple(Player player, ArrayList<ItemStack> items) {
        Inventory inventory = player.getInventory();
        for (ItemStack stack : items) {
            Ingredient ingredient = stack.getIngredient();
            int quantity = stack.getQuantity();

            if (inventory.getQuantity(ingredient) >= quantity) {
                inventory.removeIngredient(ingredient, quantity);
                int total = ingredient.getSellingPrice() * quantity;
                player.addCrystals(total);
            }
        }
    }

    /**
     * Returns listings that have not yet been purchased.
     *
     * @return available listings
     */
    public ArrayList<Listing> getAvailableListings() {
        ArrayList<Listing> availListing = new ArrayList<>();
        for (Listing listing : listings) {
            if (listing.isAvailable()) {
                availListing.add(listing);
            }
        }
        return availListing;
    }

    /** 
     * display available listings 
     */
    public void displayAvailableListings() {
        System.out.println("Available Listings:");
        for (Listing listing : getAvailableListings()) {
            if (listing.isCauldronListing()) {
                System.out.println(listing.getSlotNumber() + ": " + listing.getQuantity() + "x Cauldron for " + listing.getUnitPrice() + " crystals");
            } else {
                System.out.println(listing.getSlotNumber() + ": " + listing.getQuantity() + "x " + listing.getIngredient().getName() + " for " + (listing.getIngredient().getBuyingPrice() * listing.getQuantity()) + " crystals");
            }
        }
    }

    /**
     * Returns true when the market has been generated during the current session.
     *
     * @return true when the market has been generated
     */
    public boolean hasBeenGenerated() {
        return generatedThisSession;
    }
}